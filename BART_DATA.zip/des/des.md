1. xxx.raw 文件中带有所有数据 i.e. texts <SEP> question <SEP> ans1( </s> ans2) <SEP> attr <SEP> ex_im
2. des 路径下，是数据结构的展示
3. name 路径下，按字母排序，包含故事名类别以及属性（显隐），以下数据都是按此排序后整理的
4. cl 路径下，数据是三维的列表，实际中可以根据情况挑选 (用于对比学习，数据格式的pickle)
   - [故事名，属性名，对应内容] i.e. [1, 2, 3] 对应 第二个故事，第三个属性，第四条内容
   - source：question <SEP> texts
   - target: ans1( </s> ans2)
5. qa 路径下 (同之前bart_qa，用于复现)
   - source：question <SEP> texts
   - target: ans1( </s> ans2)
6. skill 路径下 (在之前bart_qa基础上，加入skill)
   - source：Skill: xxx <SEP> Question: xxx <SEP> Passage: xxx
   - target: ans1( </s> ans2)