---
tags:
- exbert

license: apache-2.0
---

<a href="https://huggingface.co/exbert/?model=distilgpt2">
	<img width="300px" src="https://hf-dinosaur.huggingface.co/exbert/button.png">
</a>
