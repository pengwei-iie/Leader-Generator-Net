---
language: fr
thumbnail: https://miro.medium.com/max/700/1*MoPnD6vA9wTHjdLfW7POyw.png
widget:
- text: "Le camembert LePetit c'est le <mask>."
- text: "Salut les <mask> ça va ?"
---

# LePetit: A pre-training efficient and lightning fast French Language Model

See [blogpost](https://medium.com/illuin/lepetit-a-pre-training-efficient-and-lightning-fast-french-language-model-96495ad726b3)

